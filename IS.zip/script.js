class Route {
    constructor(xmlText) {
        this.xmlDoc = new DOMParser().parseFromString(xmlText, "text/xml");
        this.points = Array.from(this.xmlDoc.getElementsByTagName('trkpt'));
        this.lats = this.points.map(x => parseFloat(x.getAttribute('lat')));
        this.lons = this.points.map(x => parseFloat(x.getAttribute('lon')));
        this.times = Array.from(this.xmlDoc.getElementsByTagName('time'));

        this.count = this.points.length;
    }

    getLats() {
        return this.lats;
    }

    getLons() {
        return this.lons;
    }

    getCount() {
        return this.count;
    }

    getStartTime() {
        return this.times[0];
    }

    getFinishTime() {
        return this.times[this.count - 1];
    }
}

function swapTab(evt, tabName) {
    // Declare all variables
    var i, tabcontent, tablinks;

    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

function sum(l) {
    return l.reduce((a, b) => a + b, 0);
}

var map = L.map('mapid').setView([51.505, -0.09], 13);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

var slider;

var route;
var trkIndex = 0;
var startMarker, finishMarker;
var playing = false;

var playingInterval;


$(document).ready(function () {

    slider = document.getElementById("progressSlider");
    slider.onchange = function() {
        console.log(this.value);

        // Update all info
        // on the right side
    };

    document.getElementById("uploadFileButton").onclick = function() {
        document.getElementById("uploadFile").click();
    };

    document.getElementById("uploadFile").addEventListener('change', function() {
        var fr = new FileReader();
        fr.onload = function () {
            
            route = new Route(this.result);
            console.log(this.result);
            var lats = route.getLats();
            var lons = route.getLons();
            var count = route.getCount();

            console.log(lats.length)

            startMarker = L.marker([lats[0], lons[0]]).addTo(map);
            finishMarker = L.marker([lats[count - 1], lons[count - 1]]).addTo(map);

            startMarker.bindPopup(route.getStartTime()).openPopup();
            finishMarker.bindPopup(route.getFinishTime()).openPopup();


            for (var i = 0; i < count - 1; i++) {

                var pointA = new L.LatLng(lats[i], lons[i]);
                var pointB = new L.LatLng(lats[i + 1], lons[i + 1]);
                var pointList = [pointA, pointB];

                var firstpolyline = new L.Polyline(pointList, {
                    color: 'grey',
                    weight: 3,
                    opacity: 1,
                    smoothFactor: 1
                });
                firstpolyline.addTo(map);
            }

            var avgLat = sum(lats) / count;
            var avgLon = sum(lons) / count;
            console.log(avgLat + " " + avgLon);
            map.setView([avgLat, avgLon], 15);
        }
        fr.readAsText(this.files[0]);
    });

    // document.getElementById("playButton").addEventListener('click', function() {
    //     playing = !playing;
    //     if (playing) {
    //         playingInterval = setInterval(function() {
    //             slider.value = parseInt(slider.value) + 1;
    //             slider.onchange();
    //             if (slider.value >= 200) {
    //                 clearInterval(playingInterval);
    //                 playingInterval = null;
    //                 playing = false;
    //             }
    //         }, 1000);
    //     } else {
    //         clearInterval(playingInterval);
    //         playingInterval = null;
    //         playing = false;
    //     }
    // });

    document.getElementById("statusTab").click();
});